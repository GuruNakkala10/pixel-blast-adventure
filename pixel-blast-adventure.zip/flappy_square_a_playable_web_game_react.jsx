import React, { useEffect, useRef, useState } from "react";

// ==================================================
// Flappy Square: Neon Fury — Pro (Home + Store + Per-Mode High Scores)
// ==================================================
// Professional features in this build:
// - Home screen (Play, Store, Settings, Credits) with coin counter & equipped skin preview
// - Difficulty selection (Easy / Normal / Insane) + Hardcore toggle
// - Gradual difficulty ramping tuned per difficulty
// - Per-mode BEST SCORES (each difficulty has its own best; Hardcore tracked separately)
// - Game Over screen with: round score, best for that mode, difficulty name, coins earned, Try Again / Home buttons
// - Store with 6 skins (coins-only). Unlock with coins earned from gameplay; equip to use in runs
// - Skins affect square color and trail effects (Rainbow has special particles)
// - High-contrast visuals + Colorblind palette toggle, Reduce Motion, Vibration toggle, Sound
// - Adaptive music + SFX, screen shake & near-miss slow-mo
// - Pause on blur, responsive UI, polished transitions
// Controls: Tap/Click/Space/↑ to flap. P to pause. R to restart.

export default function FlappySquarePro() {
  const canvasRef = useRef(null);
  const rafRef = useRef(0);
  const lastTsRef = useRef(0);

  // Views: home | playing | paused | gameover | store | settings
  const [view, setView] = useState("home");

  // Settings & options
  const [theme, setTheme] = useState(() => localStorage.getItem("fs_theme") || "neon");
  const [soundOn, setSoundOn] = useState(() => (localStorage.getItem("fs_sound") ?? "1") === "1");
  const [difficulty, setDifficulty] = useState(() => localStorage.getItem("fs_difficulty") || "normal"); // easy|normal|insane
  const [hardcore, setHardcore] = useState(() => (localStorage.getItem("fs_hc") ?? "0") === "1");
  const [colorblind, setColorblind] = useState(() => (localStorage.getItem("fs_cb") ?? "0") === "1");
  const [vibrationOn, setVibrationOn] = useState(() => (localStorage.getItem("fs_vib") ?? "1") === "1");
  const [reduceMotion, setReduceMotion] = useState(() => (localStorage.getItem("fs_motion") ?? "0") === "1");

  // Currency & skins
  const [bankCoins, setBankCoins] = useState(() => Number(localStorage.getItem("fs_bank") || 0));
  const [unlockedSkins, setUnlockedSkins] = useState(() => {
    try { return JSON.parse(localStorage.getItem("fs_skins") || "[\"classic\"]"); } catch { return ["classic"]; }
  });
  const [equippedSkin, setEquippedSkin] = useState(() => localStorage.getItem("fs_skin_equipped") || "classic");

  // Round state
  const [score, setScore] = useState(0);
  const [runCoins, setRunCoins] = useState(0); // coins earned in THIS run
  const [modeBest, setModeBest] = useState(() => getBestForMode(difficulty, hardcore));
  const [gameOverBanner, setGameOverBanner] = useState(""); // e.g., "New High Score!"

  // World & physics
  const birdRef = useRef({ x: 120, y: 220, vy: 0, size: 18, baseSize: 18 });
  const pipesRef = useRef([]); // { x, gapY, phase, speedMod, passed }
  const coinsRef = useRef([]);  // { x, y, r, taken, risky }
  const orbsRef = useRef([]);   // hazards
  const lasersRef = useRef([]); // { x, y1, y2, activeUntil }
  const puffsRef = useRef([]);
  const trailRef = useRef([]);  // trail particles for skins

  // Difficulty tuning & ramping
  const speedRef = useRef(150);
  const gravityRef = useRef(980);
  const flapImpulseRef = useRef(-320);
  const pipeGapRef = useRef(150);
  const pipeSpacingRef = useRef(230);
  const pipeWidth = 64;
  const difficultyConfig = useRef(getDifficultyConfig(difficulty, hardcore));
  const rampRef = useRef({ pipesPassed: 0, nextRampAt: 10 }); // ramp every N pipes
  const lastModeRef = useRef({ difficulty, hardcore });

  // Combo
  const comboRef = useRef({ count: 0, timer: 0, multiplier: 1 });

  // Effects
  const effectsRef = useRef({ shield: 0, slow: 0, mini: 0 });
  const screenShakeRef = useRef({ t: 0, intensity: 0 });
  const slowMotionRef = useRef({ t: 0, factor: 1 });

  // Audio (WebAudio)
  const audioCtxRef = useRef(null);
  const musicGainRef = useRef(null);
  const musicOscRef = useRef(null);

  // Persistence side-effects
  useEffect(() => { localStorage.setItem("fs_theme", theme); }, [theme]);
  useEffect(() => { localStorage.setItem("fs_sound", soundOn ? "1" : "0"); }, [soundOn]);
  useEffect(() => { localStorage.setItem("fs_difficulty", difficulty); }, [difficulty]);
  useEffect(() => { localStorage.setItem("fs_hc", hardcore ? "1" : "0"); }, [hardcore]);
  useEffect(() => { localStorage.setItem("fs_cb", colorblind ? "1" : "0"); }, [colorblind]);
  useEffect(() => { localStorage.setItem("fs_vib", vibrationOn ? "1" : "0"); }, [vibrationOn]);
  useEffect(() => { localStorage.setItem("fs_motion", reduceMotion ? "1" : "0"); }, [reduceMotion]);
  useEffect(() => { localStorage.setItem("fs_bank", String(bankCoins)); }, [bankCoins]);
  useEffect(() => { localStorage.setItem("fs_skins", JSON.stringify(unlockedSkins)); }, [unlockedSkins]);
  useEffect(() => { localStorage.setItem("fs_skin_equipped", equippedSkin); }, [equippedSkin]);

  // Coins: vibration
  const buzz = (ms = 20) => { try { if (!vibrationOn) return; if (navigator.vibrate) navigator.vibrate(ms); } catch {} };

  // Audio helpers
  const initAudio = () => {
    if (!soundOn) return;
    if (audioCtxRef.current) return;
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      const ctx = new AudioContext(); audioCtxRef.current = ctx;
      const gain = ctx.createGain(); gain.gain.value = 0.06; gain.connect(ctx.destination); musicGainRef.current = gain;
      const osc = ctx.createOscillator(); osc.type = "sawtooth"; osc.frequency.value = 80;
      const osc2 = ctx.createOscillator(); osc2.type = "sine"; osc2.frequency.value = 120;
      const g2 = ctx.createGain(); g2.gain.value = 0.25; osc.connect(g2); osc2.connect(g2); g2.connect(gain);
      osc.start(); osc2.start(); musicOscRef.current = [osc, osc2];
    } catch (e) { console.warn("Audio init failed", e); }
  };
  const stopAudio = () => { try { if (!audioCtxRef.current) return; musicOscRef.current.forEach(o=>o.stop()); audioCtxRef.current.close(); audioCtxRef.current = null; musicOscRef.current = null; musicGainRef.current = null; } catch {} };
  const sfx = (freq = 440, dur = 0.06, type = "sine", vol = 0.08) => {
    if (!soundOn) return; initAudio(); const ctx = audioCtxRef.current; if (!ctx) return;
    const o = ctx.createOscillator(); const g = ctx.createGain(); o.type = type; o.frequency.value = freq; g.gain.value = vol; o.connect(g).connect(ctx.destination); const now = ctx.currentTime; o.start(now); o.stop(now + dur);
  };
  const setMusicIntensity = (v) => { try { if (!musicGainRef.current) return; musicGainRef.current.gain.linearRampToValueAtTime(0.03 + v * 0.12, audioCtxRef.current.currentTime + 0.2); if (musicOscRef.current && musicOscRef.current[0]) musicOscRef.current[0].frequency.setTargetAtTime(60 + v * 160, audioCtxRef.current.currentTime, 0.5); } catch {} };

  // Canvas scaling
  const resizeCanvas = () => {
    const c = canvasRef.current; if (!c) return; const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const rect = c.getBoundingClientRect(); c.width = Math.floor(rect.width * dpr); c.height = Math.floor(rect.height * dpr);
    const ctx = c.getContext("2d"); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  };

  // Pause on blur
  useEffect(() => {
    const onBlur = () => { if (view === "playing") setView("paused"); };
    window.addEventListener("blur", onBlur);
    window.addEventListener("visibilitychange", () => { if (document.hidden && view === "playing") setView("paused"); });
    window.addEventListener("resize", resizeCanvas); resizeCanvas();
    return () => { window.removeEventListener("blur", onBlur); window.removeEventListener("resize", resizeCanvas); };
  }, [view]);

  // Input
  useEffect(() => {
    const onKey = (e) => {
      if (e.repeat) return;
      if (e.code === "Space" || e.code === "ArrowUp") { e.preventDefault(); userFlap(); }
      else if (e.code === "KeyP") { setView((v) => (v === "playing" ? "paused" : v === "paused" ? "playing" : v)); }
      else if (e.code === "KeyR") { if (view === "playing") { resetGame(); setView("home"); } }
    };
    const onPointer = () => userFlap();
    window.addEventListener("keydown", onKey);
    window.addEventListener("pointerdown", onPointer);
    return () => { window.removeEventListener("keydown", onKey); window.removeEventListener("pointerdown", onPointer); };
  }, [view]);

  const currentSkin = () => skins.find(s => s.id === equippedSkin) || skins[0];

  // user flap
  const userFlap = () => {
    if (view === "home") return; // tapping home shouldn't start automatically
    if (view === "store" || view === "settings") return;
    if (view === "gameover") return; // use buttons
    if (view !== "playing") return;
    const slow = effectsRef.current.slow > 0 ? 0.6 : 1;
    birdRef.current.vy = flapImpulseRef.current * slow;
    sfx(880, 0.05, "square", 0.04); buzz(10);
  };

  // Reset & start
  const resetGame = () => {
    const c = canvasRef.current; const h = c?.getBoundingClientRect().height || 400;
    birdRef.current = { x: 120, y: h / 2, vy: 0, size: 18, baseSize: 18 };
    pipesRef.current = []; coinsRef.current = []; orbsRef.current = []; lasersRef.current = []; puffsRef.current = []; trailRef.current = [];
    effectsRef.current = { shield: 0, slow: 0, mini: 0 };
    screenShakeRef.current = { t: 0, intensity: 0 }; slowMotionRef.current = { t: 0, factor: 1 };
    comboRef.current = { count: 0, timer: 0, multiplier: 1 };
    setScore(0); setRunCoins(0); setGameOverBanner("");

    const cfg = getDifficultyConfig(difficulty, hardcore); difficultyConfig.current = cfg;
    speedRef.current = cfg.startSpeed; gravityRef.current = cfg.gravity; flapImpulseRef.current = cfg.flap; pipeGapRef.current = cfg.startGap; pipeSpacingRef.current = cfg.pipeSpacing;
    rampRef.current = { pipesPassed: 0, nextRampAt: cfg.rampEvery };
    lastModeRef.current = { difficulty, hardcore };
    setModeBest(getBestForMode(difficulty, hardcore));
    if (soundOn) initAudio();
  };
  const startGame = () => { resetGame(); setView("playing"); sfx(520, 0.08, "triangle", 0.06); };

  // Spawning
  const spawnIfNeeded = (w, h) => {
    const last = pipesRef.current[pipesRef.current.length - 1];
    if (!last || last.x < w - pipeSpacingRef.current) {
      const margin = 60; const maxGapTop = h - margin - pipeGapRef.current - 40;
      const gapY = margin + Math.random() * Math.max(1, maxGapTop - margin);
      const phase = Math.random() * Math.PI * 2; const speedMod = 1 + Math.random() * 0.12;
      pipesRef.current.push({ x: w + 20, gapY, phase, speedMod, passed: false });

      // 70% chance of a coin (sometimes risky placement)
      if (Math.random() < 0.7) {
        const risky = Math.random() < 0.22; const cx = w + 20 + pipeWidth / 2; const cy = gapY + pipeGapRef.current / 2 + (risky ? ((Math.random() - 0.5) * (pipeGapRef.current * 0.65)) : 0);
        coinsRef.current.push({ x: cx, y: cy, r: 7, taken: false, risky });
      }

      // 25% chance power-up
      if (Math.random() < 0.25) {
        const kinds = ["shield", "slow", "mini"]; const kind = kinds[(Math.random() * kinds.length) | 0]; const py = gapY + 20 + Math.random() * Math.max(10, pipeGapRef.current - 40);
        powerupsRef.current.push({ x: w + 20 + pipeWidth + 90, y: py, kind, taken: false });
      }

      // hazards after early game
      if (Math.random() < 0.35 && rampRef.current.pipesPassed > 6) {
        const oy = 80 + Math.random() * (h - 160); const r = 10 + Math.random() * 8; const vx = - (speedRef.current + 60 + Math.random() * 80);
        orbsRef.current.push({ x: w + 90, y: oy, r, vx, vy: (Math.random() - 0.5) * 40 });
      }
      if (Math.random() < 0.18 && rampRef.current.pipesPassed > 10) {
        const ly = 60 + Math.random() * (h - 180); lasersRef.current.push({ x: w + 160, y1: ly, y2: ly + 60, activeUntil: 0 });
      }
    }
  };

  // Power-ups list (kept from previous build)
  const powerupsRef = useRef([]);

  // Collision helpers
  const aabbPipeCollision = (bx, by, bs, p, w, h, t) => {
    const amp = difficultyConfig.current.oscAmp; const speed = 0.9 + (rampRef.current.pipesPassed * 0.02);
    const gapY = p.gapY + Math.sin(t * 0.9 + p.phase) * amp + Math.sin(t * 5 + p.phase) * (difficultyConfig.current.oscWobble || 0);
    const inX = bx + bs > p.x && bx - bs < p.x + pipeWidth;
    const inGap = by - bs > gapY && by + bs < gapY + pipeGapRef.current;
    const topHit = by - bs < 0; const bottomHit = by + bs > h - 40;
    return topHit || bottomHit || (inX && !inGap);
  };
  const circleHit = (bx, by, bs, cx, cy, cr) => { const dx = bx - cx, dy = by - cy; return dx * dx + dy * dy < (bs + cr) * (bs + cr); };

  // Near-miss (for shake/slow-mo)
  const checkNearMiss = (bx, by, bs, p, t) => {
    const amp = difficultyConfig.current.oscAmp; const gapY = p.gapY + Math.sin(t * 0.9 + p.phase) * amp;
    const distTop = Math.abs((by - bs) - gapY); const distBot = Math.abs((by + bs) - (gapY + pipeGapRef.current));
    return Math.min(distTop, distBot) < 16;
  };

  // Particles
  const spawnPuffs = (x, y, n = 6) => { for (let i = 0; i < n; i++) puffsRef.current.push({ x, y, vx: (Math.random() - 0.5) * 90, vy: (Math.random() - 0.5) * 90, a: 1, r: 2 + Math.random() * 3 }); };

  // Main loop
  useEffect(() => {
    const c = canvasRef.current; if (!c) return; const ctx = c.getContext("2d");
    const loop = (ts) => {
      const dtRaw = Math.min(0.033, (ts - lastTsRef.current) / 1000 || 0); lastTsRef.current = ts;
      const sm = slowMotionRef.current.factor; const dt = dtRaw * sm;
      draw(dt, ctx, ts / 1000);
      if (slowMotionRef.current.t > 0) { slowMotionRef.current.t = Math.max(0, slowMotionRef.current.t - dtRaw); if (slowMotionRef.current.t === 0) slowMotionRef.current.factor = 1; }
      screenShakeRef.current.intensity = Math.max(0, screenShakeRef.current.intensity - dtRaw * 6);
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafRef.current);
  }, [view, theme, soundOn, difficulty, hardcore, colorblind, reduceMotion, equippedSkin]);

  const draw = (dt, ctx, t) => {
    const rect = canvasRef.current.getBoundingClientRect(); const w = rect.width, h = rect.height;

    // Screen shake
    const shake = screenShakeRef.current.intensity; if (!reduceMotion && shake > 0) { const sx = (Math.random() - 0.5) * shake; const sy = (Math.random() - 0.5) * shake; ctx.setTransform(1, 0, 0, 1, sx, sy); } else ctx.setTransform(1, 0, 0, 1, 0, 0);

    drawTheme(ctx, w, h, theme, colorblind);

    if (view === "playing") {
      // adaptive music
      const intensity = Math.min(1, (rampRef.current.nextRampAt - Math.max(0, rampRef.current.nextRampAt - rampRef.current.pipesPassed)) / (difficultyConfig.current.rampEvery)); setMusicIntensity(intensity);

      // effects timers
      const slow = effectsRef.current.slow > 0 ? 0.55 : 1;
      effectsRef.current.shield = Math.max(0, effectsRef.current.shield - dt);
      effectsRef.current.slow = Math.max(0, effectsRef.current.slow - dt);
      effectsRef.current.mini = Math.max(0, effectsRef.current.mini - dt);
      birdRef.current.size = birdRef.current.baseSize * (effectsRef.current.mini > 0 ? 0.68 : 1);

      // physics
      birdRef.current.vy += gravityRef.current * dt * slow; birdRef.current.y += birdRef.current.vy * dt * slow;

      // world move
      const v = speedRef.current * dt * slow;
      pipesRef.current.forEach((p) => (p.x -= v * p.speedMod));
      coinsRef.current.forEach((c) => (c.x -= v));
      powerupsRef.current.forEach((p) => (p.x -= v));
      orbsRef.current.forEach((o) => { o.x += o.vx * dt; o.y += o.vy * dt; });
      lasersRef.current.forEach((l) => { l.x -= v * 0.9; if (l.activeUntil > 0) l.activeUntil = Math.max(0, l.activeUntil - dt); else if (Math.random() < 0.002) l.activeUntil = 1.0 + Math.random() * 1.4; });

      // cleanup
      pipesRef.current = pipesRef.current.filter((p) => p.x + pipeWidth > -60);
      coinsRef.current = coinsRef.current.filter((c) => c.x + 10 > -30 && !c.taken);
      powerupsRef.current = powerupsRef.current.filter((p) => p.x + 12 > -30 && !p.taken);
      orbsRef.current = orbsRef.current.filter((o) => o.x + o.r > -40 && o.x - o.r < w + 200);
      lasersRef.current = lasersRef.current.filter((l) => l.x > -80);

      // spawn
      spawnIfNeeded(w, h);

      // difficulty ramp
      if (rampRef.current.pipesPassed >= rampRef.current.nextRampAt) {
        rampRef.current.nextRampAt += difficultyConfig.current.rampEvery; rampRef.current.pipesPassed = 0;
        speedRef.current = Math.min(difficultyConfig.current.maxSpeed, speedRef.current + difficultyConfig.current.speedStep);
        pipeGapRef.current = Math.max(difficultyConfig.current.minGap, pipeGapRef.current - difficultyConfig.current.gapStep);
        if (Math.random() < 0.6) lasersRef.current.push({ x: w + 160, y1: 50 + Math.random() * (h - 200), y2: 120 + Math.random() * (h - 200), activeUntil: 1.8 });
      }

      // score & ramp counters on passing pipes
      pipesRef.current.forEach((p) => {
        if (!p.passed && p.x + pipeWidth < birdRef.current.x - birdRef.current.size) {
          p.passed = true; setScore((s) => s + 1);
          comboRef.current.count += 1; comboRef.current.timer = 3.5; comboRef.current.multiplier = 1 + Math.min(3, comboRef.current.count * 0.12);
          rampRef.current.pipesPassed += 1; sfx(640, 0.05, "triangle", 0.06);
        }
      });

      // combo decay
      if (comboRef.current.timer > 0) comboRef.current.timer = Math.max(0, comboRef.current.timer - dt); else { comboRef.current.count = 0; comboRef.current.multiplier = 1; }

      // coin collection
      coinsRef.current.forEach((c) => {
        if (!c.taken && circleHit(birdRef.current.x, birdRef.current.y, birdRef.current.size, c.x, c.y, c.r)) {
          c.taken = true; setRunCoins((k) => k + 1); spawnPuffs(c.x, c.y, 8); sfx(930, 0.05, "sine", 0.07); if (c.risky) setScore((s)=>s + Math.round(1 * comboRef.current.multiplier)); buzz(10);
        }
      });

      // power-ups
      powerupsRef.current.forEach((p) => {
        if (!p.taken && circleHit(birdRef.current.x, birdRef.current.y, birdRef.current.size, p.x, p.y, 12)) {
          p.taken = true; spawnPuffs(p.x, p.y, 10); buzz(15); comboRef.current.count = 0; comboRef.current.multiplier = 1;
          if (p.kind === "shield") { effectsRef.current.shield = 6; sfx(440, 0.08, "square", 0.08); }
          if (p.kind === "slow") { effectsRef.current.slow = 4.8; slowMotionRef.current.t = 0.9; slowMotionRef.current.factor = 0.56; sfx(300, 0.12, "triangle", 0.09); }
          if (p.kind === "mini") { effectsRef.current.mini = 6; sfx(520, 0.1, "sine", 0.09); }
        }
      });

      // collisions
      let laserHit = false; lasersRef.current.forEach((l) => { if (l.activeUntil > 0) { if (birdRef.current.x + birdRef.current.size > l.x - 6 && birdRef.current.x - birdRef.current.size < l.x + 6) { if (birdRef.current.y > l.y1 && birdRef.current.y < l.y2) laserHit = true; } } });
      const orbHit = orbsRef.current.some((o) => circleHit(birdRef.current.x, birdRef.current.y, birdRef.current.size, o.x, o.y, o.r));
      let pipeHit = false; let near = false; pipesRef.current.forEach((p) => { if (aabbPipeCollision(birdRef.current.x, birdRef.current.y, birdRef.current.size, p, w, h, t)) pipeHit = true; else if (checkNearMiss(birdRef.current.x, birdRef.current.y, birdRef.current.size, p, t)) near = true; });

      if ((pipeHit || orbHit || laserHit) && view === "playing") {
        if (effectsRef.current.shield > 0) { effectsRef.current.shield = 0; spawnPuffs(birdRef.current.x, birdRef.current.y, 16); sfx(220, 0.06, "square", 0.06); buzz(22); birdRef.current.vy = -170; comboRef.current.count = 0; comboRef.current.multiplier = 1; }
        else {
          // finalize round: update best for mode & add coins to bank
          const key = bestKeyForMode(lastModeRef.current.difficulty, lastModeRef.current.hardcore);
          const prevBest = Number(localStorage.getItem(key) || 0);
          const newBest = Math.max(prevBest, score);
          localStorage.setItem(key, String(newBest));
          setModeBest(newBest);
          setBankCoins((b) => b + runCoins);
          setGameOverBanner(newBest > prevBest ? "New High Score!" : "");
          setView("gameover"); sfx(140, 0.22, "sawtooth", 0.08); buzz(40);
        }
      } else if (near && !reduceMotion) {
        screenShakeRef.current.intensity = Math.max(screenShakeRef.current.intensity, 6);
        slowMotionRef.current.t = Math.max(slowMotionRef.current.t, 0.4); slowMotionRef.current.factor = 0.66; sfx(1200, 0.045, "sine", 0.03);
      }
    }

    // Draw pipes/coins/powerups/lasers/orbs
    drawPipes(ctx, w, h, t);
    coinsRef.current.forEach((c) => { if (!c.taken) { ctx.save(); ctx.globalCompositeOperation = "lighter"; gradientDisk(ctx, c.x, c.y, c.r, "#fff7ae", "#ffd166"); if (c.risky) { ctx.strokeStyle = "#ff6b6b"; ctx.lineWidth = 1.5; ctx.stroke(); } ctx.restore(); } });
    powerupsRef.current.forEach((p) => drawPowerup(ctx, p.x, p.y, p.kind));
    lasersRef.current.forEach((l) => { drawLaser(ctx, l.x, l.y1, l.y2, l.activeUntil > 0); });
    orbsRef.current.forEach((o) => { ctx.save(); ctx.globalCompositeOperation = "lighter"; gradientDisk(ctx, o.x, o.y, o.r, "#ff6ec7", "#ff2d95"); ctx.restore(); });

    // Trail & particles
    drawTrail(ctx, currentSkin());
    puffsRef.current.forEach((pf) => { pf.x += pf.vx * dt; pf.y += pf.vy * dt; pf.a -= dt * 1.2; }); puffsRef.current = puffsRef.current.filter((pf) => pf.a > 0);
    puffsRef.current.forEach((pf) => { ctx.globalAlpha = pf.a; gradientDisk(ctx, pf.x, pf.y, pf.r, "#a5f3fc", "#38bdf8"); ctx.globalAlpha = 1; });

    // Bird
    drawBird(ctx, birdRef.current.x, birdRef.current.y, birdRef.current.size, currentSkin());

    // HUD top-left
    drawHUD(ctx, w, h);

    // reset transform
    ctx.setTransform(1, 0, 0, 1, 0, 0);
  };

  // Drawing helpers
  const drawTheme = (ctx, w, h, theme, cb) => {
    if (theme === "neon") {
      const g = ctx.createLinearGradient(0, 0, w, h); g.addColorStop(0, cb ? "#020014" : "#050014"); g.addColorStop(1, cb ? "#001527" : "#0a0824"); ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
      if (!reduceMotion) { ctx.globalAlpha = 0.06; ctx.strokeStyle = "#00e5ff"; for (let y = h - 60; y < h; y += 6) { ctx.fillStyle = "rgba(0,0,0,0.02)"; ctx.fillRect(0, y, w, 1); } ctx.globalAlpha = 1; }
    } else if (theme === "pastel") { const g = ctx.createLinearGradient(0, 0, 0, h); g.addColorStop(0, "#e6fffa"); g.addColorStop(1, "#f8fafc"); ctx.fillStyle = g; ctx.fillRect(0, 0, w, h); }
    else { const g = ctx.createLinearGradient(0, 0, 0, h); g.addColorStop(0, "#051622"); g.addColorStop(1, "#071f2b"); ctx.fillStyle = g; ctx.fillRect(0, 0, w, h); }
    ctx.fillStyle = "rgba(0,0,0,0.18)"; ctx.fillRect(0, h - 40, w, 40);
  };
  const drawPipes = (ctx, w, h, t) => {
    pipesRef.current.forEach((p) => {
      const amp = difficultyConfig.current.oscAmp; const phase = p.phase; const gapY = p.gapY + Math.sin(t * 0.9 + phase) * amp + Math.sin(t * 5 + phase) * (difficultyConfig.current.oscWobble || 0);
      neonRect(ctx, p.x, 0, pipeWidth, gapY, "#00e5ff"); neonRect(ctx, p.x, gapY + pipeGapRef.current, pipeWidth, h - 40 - (gapY + pipeGapRef.current), "#a855f7");
    });
  };
  const neonRect = (ctx, x, y, w, h, color) => { ctx.save(); ctx.globalCompositeOperation = "lighter"; ctx.fillStyle = color; ctx.globalAlpha = 0.18; ctx.fillRect(x - 6, y - 6, w + 12, h + 12); ctx.globalAlpha = 1; ctx.fillStyle = color; ctx.fillRect(x, y, w, h); ctx.strokeStyle = "rgba(255,255,255,0.18)"; ctx.lineWidth = 2; ctx.strokeRect(x - 2, y - 2, w + 4, h + 4); ctx.restore(); };
  const gradientDisk = (ctx, x, y, r, c1, c2) => { const g = ctx.createRadialGradient(x, y, r * 0.2, x, y, r); g.addColorStop(0, c1); g.addColorStop(1, c2); ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fillStyle = g; ctx.fill(); };
  const drawPowerup = (ctx, x, y, kind) => { ctx.save(); ctx.translate(x, y); ctx.lineWidth = 2; ctx.strokeStyle = "#22d3ee"; ctx.fillStyle = "#a7f3d0"; if (kind === "shield") { polygon(ctx, 6, 12); ctx.fill(); ctx.stroke(); } else if (kind === "slow") { ctx.beginPath(); ctx.moveTo(-10, -10); ctx.lineTo(10, -10); ctx.lineTo(-10, 10); ctx.lineTo(10, 10); ctx.stroke(); ctx.beginPath(); ctx.moveTo(-10, -10); ctx.lineTo(10, 10); ctx.moveTo(10, -10); ctx.lineTo(-10, 10); ctx.stroke(); } else if (kind === "mini") { star(ctx, 5, 0, 0, 12, 5); ctx.fill(); ctx.stroke(); } ctx.restore(); };
  const drawLaser = (ctx, x, y1, y2, active) => { ctx.save(); ctx.globalCompositeOperation = "lighter"; ctx.lineWidth = active ? 6 : 2; ctx.strokeStyle = active ? "rgba(255,80,120,0.95)" : "rgba(255,80,120,0.18)"; ctx.beginPath(); ctx.moveTo(x, y1); ctx.lineTo(x, y2); ctx.stroke(); ctx.restore(); };
  const drawBird = (ctx, x, y, s, skin) => {
    // record trail point
    trailRef.current.push({ x, y, t: performance.now(), skin }); if (trailRef.current.length > 60) trailRef.current.shift();
    ctx.save(); ctx.translate(x, y);
    gradientDisk(ctx, 0, 0, s + 10, skin.glow, "rgba(0,0,0,0)");
    ctx.fillStyle = skin.body; roundRect(ctx, -s, -s, s * 2, s * 2, 8); ctx.fill();
    ctx.fillStyle = skin.accent; roundRect(ctx, -s * 0.9, -s * 0.2, s * 1.2, s * 0.9, 6); ctx.fill();
    ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(s * 0.35, -s * 0.4, 4, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = "#111827"; ctx.beginPath(); ctx.arc(s * 0.45, -s * 0.4, 2, 0, Math.PI * 2); ctx.fill();
    if (effectsRef.current.shield > 0) { ctx.globalAlpha = 0.35; ctx.strokeStyle = "#22d3ee"; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(0, 0, s + 6, 0, Math.PI * 2); ctx.stroke(); ctx.globalAlpha = 1; }
    ctx.restore();
  };
  const drawTrail = (ctx, skin) => {
    if (skin.trail === "none") return; const now = performance.now();
    for (let i = 0; i < trailRef.current.length; i++) {
      const p = trailRef.current[i]; const age = (now - p.t) / 1000; if (age > 0.6) continue; const a = 1 - age / 0.6;
      ctx.save(); ctx.globalAlpha = a * 0.6; if (skin.trail === "glow") { gradientDisk(ctx, p.x - 10, p.y + 2, 10, skin.glow, "rgba(0,0,0,0)"); } else if (skin.trail === "spark") { gradientDisk(ctx, p.x - 6, p.y, 6, skin.accent, "rgba(0,0,0,0)"); } else if (skin.trail === "rainbow") { const hue = (i * 12) % 360; gradientDisk(ctx, p.x - 10, p.y, 8, `hsl(${hue} 100% 70%)`, "rgba(0,0,0,0)"); }
      ctx.restore();
    }
  };
  const roundRect = (ctx, x, y, w, h, r) => { const rr = Math.min(r, w / 2, h / 2); ctx.beginPath(); ctx.moveTo(x + rr, y); ctx.arcTo(x + w, y, x + w, y + h, rr); ctx.arcTo(x + w, y + h, x, y + h, rr); ctx.arcTo(x, y + h, x, y, rr); ctx.arcTo(x, y, x + w, y, rr); ctx.closePath(); };
  const polygon = (ctx, sides, r, cx = 0, cy = 0) => { ctx.beginPath(); for (let i = 0; i < sides; i++) { const a = (i / sides) * Math.PI * 2 - Math.PI / 2; const x = cx + Math.cos(a) * r, y = cy + Math.sin(a) * r; if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y); } ctx.closePath(); };
  const star = (ctx, points, cx, cy, outer, inner) => { ctx.beginPath(); for (let i = 0; i < points * 2; i++) { const r = i % 2 === 0 ? outer : inner; const a = (i / (points * 2)) * Math.PI * 2 - Math.PI / 2; const x = cx + Math.cos(a) * r, y = cy + Math.sin(a) * r; if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y); } ctx.closePath(); };

  const drawHUD = (ctx, w, h) => {
    ctx.fillStyle = "#e0f2fe"; ctx.font = "bold 24px ui-sans-serif, system-ui"; ctx.fillText(`Score: ${score}`, 16, 34);
    ctx.font = "14px ui-sans-serif, system-ui"; ctx.fillText(`Coins (run): ${runCoins}`, 16, 54);
    const mode = modeLabel(difficulty, hardcore); ctx.fillText(`Mode: ${mode}`, 16, 74);

    if (view === "home") centerText(ctx, w, h, "FLAPPY SQUARE: NEON FURY", "Tap Play on the Home screen to begin");
    if (view === "paused") centerText(ctx, w, h, "Paused", "Press P to resume");
    if (view === "gameover") {
      ctx.textAlign = "center"; ctx.font = "bold 30px ui-sans-serif, system-ui"; ctx.fillText("GAME OVER", w/2, h/2 - 120);
      ctx.font = "16px ui-sans-serif, system-ui"; ctx.fillText(`Score: ${score}`, w/2, h/2 - 88);
      ctx.fillText(`Best (${mode}): ${modeBest}`, w/2, h/2 - 60);
      ctx.fillText(`Coins this run: +${runCoins}`, w/2, h/2 - 32);
      if (gameOverBanner) { ctx.font = "bold 18px ui-sans-serif, system-ui"; ctx.fillText(gameOverBanner, w/2, h/2 - 4); }
      ctx.textAlign = "left";
    }
  };
  const centerText = (ctx, w, h, a, b) => { ctx.textAlign = "center"; ctx.fillStyle = "#e0f2fe"; ctx.globalAlpha = 0.95; ctx.font = "bold 30px ui-sans-serif, system-ui"; ctx.fillText(a, w / 2, h / 2 - 10); ctx.font = "14px ui-sans-serif, system-ui"; ctx.fillText(b, w / 2, h / 2 + 18); ctx.textAlign = "left"; ctx.globalAlpha = 1; };

  // ===== UI helpers =====
  function modeLabel(diff, hc) { return `${diff[0].toUpperCase()}${diff.slice(1)}${hc ? " Hardcore" : ""}`; }
  function bestKeyForMode(diff, hc) { return `fs_best_${diff}${hc ? "_hc" : ""}`; }
  function getBestForMode(diff, hc) { return Number(localStorage.getItem(bestKeyForMode(diff, hc)) || 0); }

  // ===== Skins data =====
  const skins = [
    { id: "classic", name: "Classic Neon", price: 0, body: "#22d3ee", accent: "#0ea5e9", glow: "rgba(34,211,238,0.18)", trail: "glow" },
    { id: "cyber", name: "Cyber Blue", price: 50, body: "#60a5fa", accent: "#3b82f6", glow: "rgba(59,130,246,0.18)", trail: "glow" },
    { id: "lava", name: "Lava Red", price: 100, body: "#f87171", accent: "#ef4444", glow: "rgba(248,113,113,0.18)", trail: "spark" },
    { id: "emerald", name: "Emerald Glow", price: 200, body: "#34d399", accent: "#10b981", glow: "rgba(16,185,129,0.18)", trail: "glow" },
    { id: "golden", name: "Golden Pulse", price: 500, body: "#fbbf24", accent: "#f59e0b", glow: "rgba(245,158,11,0.18)", trail: "spark" },
    { id: "rainbow", name: "Rainbow Trail", price: 1000, body: "#e879f9", accent: "#c084fc", glow: "rgba(192,132,252,0.18)", trail: "rainbow" },
  ];

  // ===== Render =====
  return (
    <div className="min-h-screen w-full bg-black text-cyan-50 flex flex-col items-center p-4 gap-4 select-none">
      {/* Top Bar */}
      <header className="w-full max-w-3xl flex items-center justify-between">
        <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight">Flappy Square: Neon Fury — Pro</h1>
        <div className="flex items-center gap-2">
          <CoinPill amount={bankCoins} />
          <button onClick={() => setView("home")} className="px-3 py-2 rounded-2xl shadow bg-white/6 hover:bg-white/12 text-sm">Home</button>
          <button onClick={() => setView("store")} className="px-3 py-2 rounded-2xl shadow bg-white/6 hover:bg-white/12 text-sm">Store</button>
          <button onClick={() => setView("settings")} className="px-3 py-2 rounded-2xl shadow bg-white/6 hover:bg-white/12 text-sm">Settings</button>
        </div>
      </header>

      {/* Canvas */}
      <div className="relative w-full max-w-3xl aspect-[9/16] md:aspect-[3/2] bg-transparent rounded-2xl shadow-lg border border-cyan-200/12 overflow-hidden">
        <canvas ref={canvasRef} className="w-full h-full block" />
        {/* Game Over Overlay Buttons */}
        {view === "gameover" && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/30">
            <div className="flex gap-3">
              <button onClick={() => { setView("playing"); startGame(); }} className="px-4 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-300/30">Try Again</button>
              <button onClick={() => setView("home")} className="px-4 py-2 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-300/30">Home</button>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Panel (changes by view) */}
      <div className="w-full max-w-3xl">
        {view === "home" && (
          <HomePanel
            difficulty={difficulty}
            setDifficulty={setDifficulty}
            hardcore={hardcore}
            setHardcore={setHardcore}
            theme={theme}
            setTheme={setTheme}
            equippedSkin={equippedSkin}
            onPlay={startGame}
            currentSkin={currentSkin()}
          />
        )}
        {view === "store" && (
          <StorePanel
            skins={skins}
            bankCoins={bankCoins}
            unlockedSkins={unlockedSkins}
            equippedSkin={equippedSkin}
            onUnlock={(id, price) => {
              if (unlockedSkins.includes(id)) return;
              if (bankCoins < price) return sfx(180, 0.08, "sine", 0.06);
              setBankCoins((b) => b - price);
              setUnlockedSkins((u) => [...new Set([...u, id])]);
              setEquippedSkin(id);
              sfx(880, 0.12, "square", 0.09);
            }}
            onEquip={(id) => { setEquippedSkin(id); sfx(640, 0.08, "triangle", 0.07); }}
          />
        )}
        {view === "settings" && (
          <SettingsPanel
            theme={theme}
            setTheme={setTheme}
            soundOn={soundOn}
            setSoundOn={(v)=>{ setSoundOn(v); if (v) initAudio(); else stopAudio(); }}
            colorblind={colorblind}
            setColorblind={setColorblind}
            vibrationOn={vibrationOn}
            setVibrationOn={setVibrationOn}
            reduceMotion={reduceMotion}
            setReduceMotion={setReduceMotion}
            onClose={() => setView("home")}
          />
        )}
      </div>
    </div>
  );
}

// =====================
// Helper: difficulty configs
// =====================
function getDifficultyConfig(level = "normal", hardcore = false) {
  const base = {
    easy:   { startSpeed: 120, gravity: 900,  flap: -300, startGap: 180, pipeSpacing: 260, rampEvery: 12, speedStep: 6, gapStep: 6, minGap: 140, maxSpeed: 300, oscAmp: 8,  oscWobble: 1 },
    normal: { startSpeed: 160, gravity: 980,  flap: -320, startGap: 150, pipeSpacing: 230, rampEvery: 10, speedStep: 8, gapStep: 6, minGap: 120, maxSpeed: 340, oscAmp: 14, oscWobble: 3 },
    insane: { startSpeed: 200, gravity: 1120, flap: -340, startGap: 130, pipeSpacing: 210, rampEvery: 8,  speedStep: 10, gapStep: 8, minGap: 95,  maxSpeed: 420, oscAmp: 22, oscWobble: 5 },
  };
  const cfg = base[level] ? { ...base[level] } : { ...base.normal };
  if (hardcore) { cfg.startSpeed += 12; cfg.gravity += 80; cfg.flap -= 8; cfg.minGap = Math.max(80, cfg.minGap - 10); cfg.maxSpeed += 30; }
  return cfg;
}

// =====================
// Panels & small components (Tailwind UI)
// =====================
function CoinPill({ amount }) {
  return (
    <div className="px-3 py-1 rounded-full border border-yellow-300/40 bg-yellow-500/10 text-yellow-300 flex items-center gap-2">
      <span className="inline-block w-2.5 h-2.5 rounded-full bg-yellow-300" />
      <span className="text-sm font-semibold">{amount}</span>
    </div>
  );
}

function HomePanel({ difficulty, setDifficulty, hardcore, setHardcore, theme, setTheme, equippedSkin, onPlay, currentSkin }) {
  return (
    <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="md:col-span-2 p-4 rounded-2xl border border-cyan-200/20 bg-white/5">
        <h2 className="text-xl font-bold mb-2">Play</h2>
        <div className="flex flex-wrap items-center gap-3">
          <label className="text-sm">Difficulty</label>
          <select value={difficulty} onChange={(e)=>setDifficulty(e.target.value)} className="px-3 py-2 rounded-xl border bg-white/6">
            <option value="easy">Easy</option>
            <option value="normal">Normal</option>
            <option value="insane">Insane</option>
          </select>
          <label className="text-sm ml-2">Hardcore</label>
          <button onClick={()=>setHardcore((s)=>!s)} className="px-3 py-2 rounded-xl border bg-white/6">{hardcore ? "On" : "Off"}</button>
          <button onClick={onPlay} className="px-5 py-2 rounded-2xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-300/30 font-semibold">Play</button>
        </div>
        <div className="mt-4 flex items-center gap-3">
          <label className="text-sm">Theme</label>
          <select value={theme} onChange={(e) => setTheme(e.target.value)} className="px-3 py-2 rounded-xl border bg-white/6">
            <option value="neon">Neon</option>
            <option value="cyber">Cyber</option>
            <option value="pastel">Pastel</option>
          </select>
        </div>
      </div>
      <div className="p-4 rounded-2xl border border-cyan-200/20 bg-white/5">
        <h3 className="font-semibold mb-2">Equipped Skin</h3>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl" style={{ background: currentSkin.body, boxShadow: `0 0 24px ${currentSkin.glow}` }} />
          <div>
            <p className="text-sm font-semibold">{currentSkin.name}</p>
            <p className="text-xs text-cyan-200/70">Trail: {currentSkin.trail}</p>
          </div>
        </div>
        <button onClick={() => window.scrollTo({ top: 9999, behavior: 'smooth' })} className="mt-3 text-sm underline opacity-80" aria-label="Scroll to Store">Go to Store ↓</button>
      </div>
    </div>
  );
}

function StorePanel({ skins, bankCoins, unlockedSkins, equippedSkin, onUnlock, onEquip }) {
  return (
    <div className="mt-3 p-4 rounded-2xl border border-cyan-200/20 bg-white/5">
      <h2 className="text-xl font-bold mb-3">Store</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {skins.map((s) => {
          const owned = unlockedSkins.includes(s.id);
          const equipped = equippedSkin === s.id;
          return (
            <div key={s.id} className={`p-3 rounded-2xl border ${equipped ? 'border-cyan-300/70' : 'border-cyan-200/20'} bg-black/40 flex flex-col gap-2`}>
              <div className="h-20 rounded-xl" style={{ background: s.body, boxShadow: `0 0 24px ${s.glow}` }} />
              <div className="flex-1">
                <p className="font-semibold text-sm">{s.name}</p>
                {s.price > 0 && <p className="text-xs text-cyan-200/70">Price: {s.price} coins</p>}
                {s.price === 0 && <p className="text-xs text-cyan-200/70">Free</p>}
              </div>
              <div className="flex gap-2">
                {!owned && (
                  <button onClick={() => onUnlock(s.id, s.price)} disabled={bankCoins < s.price} className={`px-3 py-1 rounded-xl border ${bankCoins < s.price ? 'opacity-50' : 'hover:bg-cyan-500/20'} border-cyan-300/30`}>Unlock</button>
                )}
                {owned && !equipped && (
                  <button onClick={() => onEquip(s.id)} className="px-3 py-1 rounded-xl border hover:bg-cyan-500/20 border-cyan-300/30">Equip</button>
                )}
                {equipped && <span className="px-3 py-1 rounded-xl border border-cyan-300/50 text-cyan-200 text-sm">Equipped</span>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function SettingsPanel({ theme, setTheme, soundOn, setSoundOn, colorblind, setColorblind, vibrationOn, setVibrationOn, reduceMotion, setReduceMotion, onClose }) {
  return (
    <div className="mt-3 p-4 rounded-2xl border border-cyan-200/20 bg-white/5">
      <h2 className="text-xl font-bold mb-3">Settings</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div className="flex items-center justify-between"><label className="font-medium">Sound</label><button onClick={() => setSoundOn(!soundOn)} className="px-3 py-2 rounded-xl border bg-white/6">{soundOn ? "On" : "Off"}</button></div>
        <div className="flex items-center justify-between"><label className="font-medium">Theme</label><select value={theme} onChange={(e) => setTheme(e.target.value)} className="px-3 py-2 rounded-xl border bg-white/6"><option value="neon">Neon</option><option value="cyber">Cyber</option><option value="pastel">Pastel</option></select></div>
        <div className="flex items-center justify-between"><label className="font-medium">Colorblind Palette</label><button onClick={() => setColorblind(!colorblind)} className="px-3 py-2 rounded-xl border bg-white/6">{colorblind ? "On" : "Off"}</button></div>
        <div className="flex items-center justify-between"><label className="font-medium">Reduce Motion</label><button onClick={() => setReduceMotion(!reduceMotion)} className="px-3 py-2 rounded-xl border bg-white/6">{reduceMotion ? "On" : "Off"}</button></div>
        <div className="flex items-center justify-between"><label className="font-medium">Vibration</label><button onClick={() => setVibrationOn(!vibrationOn)} className="px-3 py-2 rounded-xl border bg-white/6">{vibrationOn ? "On" : "Off"}</button></div>
      </div>
      <div className="flex justify-end mt-3"><button onClick={onClose} className="px-4 py-2 rounded-xl border bg-white/6">Close</button></div>
    </div>
  );
}
